<?php
session_start();  // Certifique-se de que session_start() é chamado no início

// Verifica se a ação de logout foi solicitada
if (isset($_GET['logout'])) {
    // Limpa a sessão
    $_SESSION = array(); // Esvazia o array de sessão

    // Se a sessão estiver usando cookies, exclua o cookie da sessão
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 4000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }

    // Finalmente, destrói a sessão
    session_destroy();

    // Redireciona para a página de login
    header("Location: ../index.html");
    exit();
}
?>
