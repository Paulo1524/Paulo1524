<?php
// Inicia a sessão se ela ainda não estiver iniciada
if (session_status() === PHP_SESSION_NONE) {
    // Define o tempo de expiração da sessão para 1 hora (3600 segundos)
    ini_set('session.gc_maxlifetime', 3600);
    session_set_cookie_params(3600);
    session_start();
}

// Verifica se o usuário está logado
if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
    // Redireciona o usuário para a página de login se não estiver logado
    header('Location: ../index.html');
    exit(); // Interrompe a execução do script para garantir que o restante da página não seja carregado
}
?>
