<?php
include 'db-login.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Proteção contra SQL injection com mysqli_real_escape_string
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // Seleção do usuário com permissao_liberar_acesso
    $stmt = $conn->prepare("SELECT id, nome, password, acesso, permissao_liberar_acesso FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        // Verificação da senha
        if (password_verify($password, $user['password'])) {
            // Login bem-sucedido
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_nome'] = $user['nome'];
            $_SESSION['permissao_liberar_acesso'] = $user['permissao_liberar_acesso'];
            $_SESSION['acesso'] = $user['acesso'];
            $_SESSION['user_logged_in'] = true;

            // Redireciona para a área restrita
            header("Location: ../restricted/dashboard.php");
            exit();
        } else {
            // Redirecionar em caso de senha inválida
            header("Location: ../index.html?error=invalid_password");
            exit();
        }
    } else {
        // Redirecionar em caso de e-mail não encontrado
        header("Location: ../index.html?error=email_not_found");
        exit();
    }
}
?>
