<?php
// Inclui a conexão com o banco de dados
include 'db-login.php';

// Verifica se o método da requisição é POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recebe e limpa os dados do formulário
    $nome = mysqli_real_escape_string($conn, $_POST['nome']);
    $endereco = mysqli_real_escape_string($conn, $_POST['endereco']);
    $telefone = mysqli_real_escape_string($conn, $_POST['telefone']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // Verifica se o e-mail já existe no banco
    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "E-mail já cadastrado!";
    } else {
        // Criptografa a senha antes de inserir no banco de dados
        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        // Prepara a query de inserção
        $stmt = $conn->prepare("INSERT INTO usuarios (nome, endereco, telefone, email, password) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $nome, $endereco, $telefone, $email, $password_hash);

        if ($stmt->execute()) {
            header("Location: ../index.html");
        } else {
            echo "Erro: " . $stmt->error;
        }
    }

    // Fecha a conexão e a instrução preparada
    $stmt->close();
    $conn->close();
}
?>
