<?php
include 'db-login.php';
session_start();
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_nome'])) {
    header("Location: ../login.php"); // Redireciona se não estiver logado
    exit();
}

// Verificar se o usuário tem acesso
$stmt = $conn->prepare("SELECT acesso_liberado FROM usuarios WHERE id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($user['acesso_liberado'] != 1) {
    header("Location: ../restricted/pendente.php"); // Redireciona se não tiver acesso
    exit();
}
?>