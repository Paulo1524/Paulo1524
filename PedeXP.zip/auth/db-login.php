<?php
$servername = "localhost";
$username = "pedexp44_adm";
$password = "adm2024#@";
$dbname = "pedexp44_login";

// Criar conex���o
$conn = new mysqli($servername, $username, $password, $dbname);

// Checar conex���o
if ($conn->connect_error) {
    die("Conex���o falhou: " . $conn->connect_error);
}
?>
