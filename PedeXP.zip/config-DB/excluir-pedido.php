<?php
include 'DB-pedidos.php'; // Inclua a sua conexão com o banco de dados

header('Content-Type: application/json');

$response = ['success' => false, 'message' => 'Não foi possível excluir o pedido.'];

error_log('Exclusão de pedido iniciada.');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Captura o ID do pedido
    $pedidoId = isset($_POST['pedido_id']) ? $_POST['pedido_id'] : null;

    if (!empty($pedidoId)) {
        error_log('ID do Pedido recebido para exclusão: ' . $pedidoId);

        // Exclui o pedido da tabela "Pedidos"
        $sql = "DELETE FROM Pedidos WHERE id_pedido = ?";
        $stmt = $conn->prepare($sql);

        if ($stmt === false) {
            error_log('Erro ao preparar a exclusão do pedido: ' . $conn->error);
            $response['message'] = 'Erro ao preparar a exclusão do pedido.';
        } else {
            $stmt->bind_param("i", $pedidoId);

            if ($stmt->execute()) {
                $response['success'] = true;
                $response['message'] = 'Pedido excluído com sucesso.';
                error_log('Pedido excluído com sucesso. ID: ' . $pedidoId);
            } else {
                error_log('Erro ao executar a exclusão do pedido: ' . $stmt->error);
                $response['message'] = 'Erro ao excluir o pedido: ' . $stmt->error;
            }

            $stmt->close();
        }
    } else {
        error_log('ID do pedido inválido ou não recebido.');
        $response['message'] = 'ID do pedido inválido.';
    }
} else {
    error_log('Método de requisição inválido.');
    $response['message'] = 'Método de requisição inválido.';
}

$conn->close();
echo json_encode($response);
?>
