<?php include 'navbar.php'; ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../src/style/novo-pedido-style.css">
    <title>Novo-Pedido</title>
</head>
<body>
    <div id="box">
        <div class="form-section">
        <h2> Novo Pedido</h2>

        <!-- Div para exibir a mensagem de sucesso ou erro -->
        <div id="mensagem"></div>
        <!-- FORMULARIO -->
        <form id="pedidoForm" action="../config-DB/inserir-pedido.php" method="post">
            <div>
                <label for="numeroPedido"><i class="fas fa-hashtag icon"></i>Número do Pedido:</label>
                <input type="text" id="numeroPedido" name="numeroPedido" required>
            </div>

            <div id="volumes">
                <div class="volume">
                    <label for="quantidadeVolumes"><i class="fas fa-box icon"></i>Quantidade de Volumes:</label>
                    <input type="number" name="quantidadeVolumes[]" required>

                    <label for="localPosicao"><i class="fas fa-map-pin icon"></i>Local/Posição do Pedido:</label>
                    <input type="text" name="localPosicao[]" required>
                </div>
            </div>
            <div id="botoes">
                <input type="hidden" id="dataPedido" name="dataPedido">
                <button type="submit"><i class="fas fa-paper-plane"></i> Endereçar Pedido</button>
            </div>

        </form>



    </div>
    </div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var form = document.getElementById('pedidoForm');
        form.addEventListener('submit', function(event) {
            event.preventDefault(); // Previne o envio tradicional do formulário

            var formData = new FormData(form);
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "../config-DB/inserir-pedido.php", true);
            xhr.onload = function () {
                if (xhr.status >= 200 && xhr.status < 300) {
                    var response = JSON.parse(xhr.responseText);
                    document.getElementById('mensagem').innerHTML = response.message;
                    // Limpa o formulário após o sucesso
                    form.reset();

                    // Limpa a mensagem e todos os volumes adicionais após 4 segundos
                    setTimeout(function() {
                        document.getElementById('mensagem').innerHTML = '';
                        // Remove todos os volumes adicionais
                        var volumes = document.querySelectorAll('#volumes .volume');
                        volumes.forEach(function(volume, index) {
                            if (index !== 0) { // Preserva o primeiro volume padrão
                                volume.remove();
                            }
                        });
                    }, 4000);
                } else {
                    document.getElementById('mensagem').innerHTML = "Erro ao enviar o pedido: " + xhr.status;
                }
            };
            xhr.onerror = function () {
                document.getElementById('mensagem').innerHTML = "Erro ao processar a solicitação.";
            };
            xhr.send(formData);
        });

        // Inicializa a data no campo oculto
        var dataAtual = new Date();
        var dia = String(dataAtual.getDate()).padStart(2, '0');
        var mes = String(dataAtual.getMonth() + 1).padStart(2, '0'); // Janeiro é 0
        var ano = dataAtual.getFullYear();
        var dataFormatada = ano + '-' + mes + '-' + dia; // Formato YYYY-MM-DD
        document.getElementById('dataPedido').value = dataFormatada;
    });

    // JS Para adicionar linhas de Volume
    function addVolume() {
        var container = document.getElementById("volumes");
        var newVolume = document.createElement("div");
        newVolume.className = "volume";
        newVolume.innerHTML = `
            <label for="quantidadeVolumes">Quantidade de Volumes:</label>
            <input type="number" name="quantidadeVolumes[]" required>
            <label for="localPosicao">Local/Posição do Pedido:</label>
            <input type="text" name="localPosicao[]" required>`;
        container.appendChild(newVolume);
    }

</script>

</body>
</html>
