<?php
include 'DB-pedidos.php';  // Inclui a conexão com o banco de dados

$response = ['success' => false, 'message' => 'Não foi possível atualizar o pedido.'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $pedidoId = $_POST['pedidoId'];
    $numeroPedido = strtoupper($_POST['numeroPedido']);  // Recebe o número do pedido
    $quantidade = $_POST['quantidadeVolumes'];
    $posicao = strtoupper($_POST['localPosicao']);

    // Prepara a query SQL para atualização
    $sql = "UPDATE Pedidos SET numero_pedido = ?, quantidade_pedido = ?, local_pedido = ? WHERE id_pedido = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        $response['message'] = "Erro ao preparar a consulta: " . $conn->error;
        echo json_encode($response);
        exit;
    }

    // Vincula os parâmetros à consulta preparada
    $stmt->bind_param("sisi", $numeroPedido, $quantidade, $posicao, $pedidoId);

    // Executa a consulta
    if ($stmt->execute()) {
        $response['success'] = true;
        $response['message'] = 'Pedido atualizado com sucesso!';
    } else {
        $response['message'] = "Erro ao atualizar pedido: " . $stmt->error;
    }

    // Fecha o statement
    $stmt->close();
} else {
    $response['message'] = "Método de requisição inválido.";
}

// Fecha a conexão
$conn->close();

echo json_encode($response);  // Retorna a resposta como JSON
?>
