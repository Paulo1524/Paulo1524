<?php
include 'DB-pedidos.php';  // Inclui o arquivo de conexão MySQLi

// Captura os dados do formulário
$numeroPedido = strtoupper($_POST['numeroPedido']);  // Converte o número do pedido para maiúsculas
$quantidadePedido = intval($_POST['quantidadeVolumes']);  // Garante que seja um número inteiro
$localPedido = strtoupper($_POST['localPosicao']);  // Converte a posição para maiúsculas

// Captura a data atual em formato YYYY-MM-DD
$dataPedido = date('Y-m-d');

// Inserir pedido na tabela "Pedidos"
$stmt = $conn->prepare("INSERT INTO Pedidos (numero_pedido, quantidade_pedido, local_pedido, data_pedido) VALUES (?, ?, ?, ?)");
if ($stmt === false) {
    echo json_encode(['success' => false, 'message' => 'Erro ao preparar a query: ' . $conn->error]);
    exit;
}
$stmt->bind_param("siss", $numeroPedido, $quantidadePedido, $localPedido, $dataPedido);  // Vincula os parâmetros
if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Pedido inserido com sucesso!']);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao inserir o pedido: ' . $stmt->error]);
}

$stmt->close();  // Fecha o statement

// Fecha a conexão com o banco de dados
$conn->close();
?>
