<?php
include 'DB-pedidos.php';  // Inclui a conexão com o banco de dados

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $localPosicao = $_POST['localPosicao'];

    // Verificar se a posição já está ocupada
    $stmt = $conn->prepare("SELECT numero_pedido FROM Pedidos WHERE local_pedido = ?");
    $stmt->bind_param("s", $localPosicao);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Retorna o número do pedido que está ocupando a posição
        echo json_encode(['ocupado' => true, 'numero_pedido' => $row['numero_pedido']]);
    } else {
        // Posição está livre
        echo json_encode(['ocupado' => false]);
    }

    $stmt->close();
    $conn->close();
}
?>
