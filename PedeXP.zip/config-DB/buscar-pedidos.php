<?php
include 'DB-pedidos.php'; // Inclua sua conexão com o banco de dados

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verifica se a busca é por data
    if (isset($_POST['tipoBusca']) && $_POST['tipoBusca'] === 'data') {
        $dataInicio = $_POST['dataInicio'];
        $dataFim = $_POST['dataFim'];

        // Modifica a data final para incluir o fim do dia
        $dataFim .= " 23:59:59";

        // Consulta para buscar pedidos por data
        $sql = "SELECT id_pedido, numero_pedido, data_pedido, quantidade_pedido, local_pedido
                FROM Pedidos
                WHERE data_pedido BETWEEN ? AND ?";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $dataInicio, $dataFim);

    } else {
        // Busca por número do pedido
        $numeroPedido = $_POST['buscaNumeroPedidoInput'];

        // Consulta para buscar pedidos pelo número do pedido
        $sql = "SELECT id_pedido, numero_pedido, data_pedido, quantidade_pedido, local_pedido
                FROM Pedidos
                WHERE numero_pedido = ?";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $numeroPedido);
    }

    // Executa a consulta
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Exibe os pedidos encontrados
        while ($row = $result->fetch_assoc()) {
            echo "<div class='resultado'>";
            echo "<p><strong>Número do Pedido:</strong> " . htmlspecialchars($row['numero_pedido']) . "</p>";
            echo "<p><strong>Data do Pedido:</strong> " . htmlspecialchars($row['data_pedido']) . "</p>";
            echo "<p><strong>Quantidade de Volumes:</strong> " . htmlspecialchars($row['quantidade_pedido']) . "</p>";
            echo "<p><strong>Local/Posição:</strong> " . htmlspecialchars($row['local_pedido']) . "</p>";

            // Botões para editar e excluir o pedido
            echo "<button style='margin-right: 10px;' onclick=\"openModal('{$row['id_pedido']}', '{$row['numero_pedido']}', '{$row['quantidade_pedido']}', '{$row['local_pedido']}')\">Editar</button>";
            echo "<button onclick=\"confirmarExclusao('{$row['id_pedido']}')\">Excluir</button>";
            echo "</div>";
        }
    } else {
        echo "<p>Nenhum pedido encontrado.</p>";
    }

    // Fecha a conexão
    $stmt->close();
    $conn->close();
}
?>
