<?php

$servername = "localhost";
$username = "pedexp44_adm";
$password = "adm2024#@";
$database = "pedexp44_pedidos";

// Criando a conexão
$conn = new mysqli($servername, $username, $password, $database);

// Verificando a conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
