<?php
// atualizar-pedido.php
include 'DB-pedidos.php'; // Inclua sua configuração do banco de dados

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $numeroPedido = $_POST['editNumeroPedido'];
    $quantidadeVolumes = $_POST['editQuantidadeVolumes'];
    $localPosicao = $_POST['editLocalPosicao'];

    // Prepare a consulta SQL para atualizar o pedido, sem alterar a data de criação
    $stmt = $conn->prepare("UPDATE pedidos SET quantidade_volumes = ?, local_posicao = ? WHERE numero_pedido = ?");
    $stmt->bind_param("isi", $quantidadeVolumes, $localPosicao, $numeroPedido);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Erro ao atualizar o pedido."]);
    }

    $stmt->close();
    $conn->close();
}
?>
