<?php include 'navbar.php'; ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../src/style/buscar-pedido-style.css">
    <title>Buscar-Pedido</title>
</head>
<body>
    <div id="box">
        <div class="search-section">
            <h2><i class="fas fa-search"></i> Buscar Pedidos</h2>
            <form id="buscaForm">
                <div class="search-type">
                    <label>
                        <input type="radio" name="tipoBusca" value="data" checked> Buscar por Data
                    </label>
                    <label>
                        <input type="radio" name="tipoBusca" value="numero"> Buscar por Número do Pedido
                    </label>
                </div>
                <div id="buscaData" class="search-filters">
                    <div>
                        <label for="dataInicio">Data Início:</label>
                        <input type="date" id="dataInicio" name="dataInicio">
                    </div>
                    <div>
                        <label for="dataFim">Data Fim:</label>
                        <input type="date" id="dataFim" name="dataFim">
                    </div>
                </div>
                <div id="buscaNumeroPedido" class="search-filters" style="display: none;">
                    <div>
                        <label for="buscaNumeroPedidoInput">Número do Pedido:</label>
                        <input type="text" id="buscaNumeroPedidoInput" name="buscaNumeroPedidoInput">
                    </div>
                </div>
                <div class="button-group">
                    <button type="submit">Buscar Pedidos</button>
                    <button type="button" id="limparBusca" class="clear-button">Limpar Busca</button>
                </div>
            </form>
            <div id="resultados" class="result-section"></div>
        </div>
    </div>

    <!-- Modal de Edição -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>Editar Pedido</h2>
            <form id="editForm">
                <input type="hidden" id="editPedidoId" name="pedidoId">
                
                <label for="editNumeroPedido">Número do Pedido:</label>
                <input type="text" id="editNumeroPedido" name="numeroPedido" required>

                <label for="editQuantidadeVolumes">Quantidade de Volumes:</label>
                <input type="number" id="editQuantidadeVolumes" name="quantidadeVolumes" required>

                <label for="editLocalPosicao">Local/Posição:</label>
                <input type="text" id="editLocalPosicao" name="localPosicao" required>

                <button type="submit">Salvar Alterações</button>
            </form>
        </div>
    </div>

    <script>
        // Função para abrir o modal e preencher os campos com os dados do pedido
        function openModal(pedidoId, numero, quantidade, posicao) {
            document.getElementById('editPedidoId').value = pedidoId;
            document.getElementById('editNumeroPedido').value = numero;  // Preenche o número do pedido
            document.getElementById('editQuantidadeVolumes').value = quantidade;
            document.getElementById('editLocalPosicao').value = posicao;
            document.getElementById('editModal').style.display = 'block';
        }

        // Função para fechar o modal
        function closeModal() {
            document.getElementById('editModal').style.display = 'none';
        }

        // Função para buscar e atualizar a lista de pedidos
        function atualizarListaPedidos() {
            const formData = new FormData(document.getElementById('buscaForm')); // Reaproveita os filtros de busca
            fetch("../config-DB/buscar-pedidos.php", {
                method: "POST",
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                document.getElementById('resultados').innerHTML = data; // Atualiza a lista com os novos dados
            })
            .catch(error => console.error('Erro ao buscar pedidos: ', error));
        }

        // Listener para o formulário de edição
        document.getElementById('editForm').addEventListener('submit', function(event) {
            event.preventDefault();
            const formData = new FormData(this);
            fetch('../config-DB/editar-pedido.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                alert('Pedido atualizado com sucesso!');
                closeModal();
                atualizarListaPedidos(); // Atualiza a lista de pedidos após a edição
            })
            .catch(error => alert('Erro ao atualizar pedido: ' + error));
        });

        // Alternar entre busca por data e número do pedido
        document.querySelectorAll('input[name="tipoBusca"]').forEach((elem) => {
            elem.addEventListener("change", function(event) {
                const buscaData = document.getElementById("buscaData");
                const buscaNumeroPedido = document.getElementById("buscaNumeroPedido");
                if (event.target.value === "data") {
                    buscaData.style.display = "block";
                    buscaNumeroPedido.style.display = "none";
                } else {
                    buscaData.style.display = "none";
                    buscaNumeroPedido.style.display = "block";
                }
            });
        });

        // Envio do formulário de busca de pedidos
        document.getElementById('buscaForm').addEventListener('submit', function(event) {
            event.preventDefault();
            atualizarListaPedidos(); // Atualiza a lista de pedidos quando o formulário é enviado
        });

        // Limpar a busca e redefinir o formulário
        document.getElementById('limparBusca').addEventListener('click', function() {
            document.getElementById('buscaForm').reset();
            document.getElementById('resultados').innerHTML = '';
            document.getElementById("buscaData").style.display = "block";
            document.getElementById("buscaNumeroPedido").style.display = "none";
        });

        // Função para confirmar e excluir o pedido
        function confirmarExclusao(pedidoId) {
            if (confirm('Deseja realmente excluir este pedido?')) {
                const formData = new FormData();
                formData.append('pedido_id', pedidoId);

                fetch('../config-DB/excluir-pedido.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Pedido excluído com sucesso!');
                        atualizarListaPedidos(); // Atualiza a lista de pedidos após exclusão
                    } else {
                        alert('Erro ao excluir o pedido: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Erro:', error);
                    alert('Erro ao excluir o pedido.');
                });
            }
        }
    </script>
</body>
</html>
