<?php include 'navbar.php'; ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../src/style/novo-pedido-style.css">
    <title>Novo-Pedido</title>
</head>
<body>
    <div id="box">
        <div class="form-section">
            <h2>Novo Pedido</h2>

            <!-- Div para exibir a mensagem de sucesso ou erro -->
            <div id="mensagem"></div>

            <!-- FORMULARIO -->
            <form id="pedidoForm" action="../config-DB/inserir-pedido.php" method="post">
                <div>
                    <label for="numeroPedido"><i class="fas fa-hashtag icon"></i>Número do Pedido:</label>
                    <input type="text" id="numeroPedido" name="numeroPedido" required>
                </div>

                <div>
                    <label for="quantidadeVolumes"><i class="fas fa-box icon"></i>Quantidade de Volumes:</label>
                    <input type="number" id="quantidadeVolumes" name="quantidadeVolumes" required>
                </div>

                <div>
                    <label for="localPosicao"><i class="fas fa-map-pin icon"></i>Local/Posição do Pedido:</label>
                    <input type="text" id="localPosicao" name="localPosicao" required>
                </div>

                <div id="botoes">
                    <input type="hidden" id="dataPedido" name="dataPedido">
                    <button type="submit"><i class="fas fa-paper-plane"></i> Endereçar Pedido</button>
                </div>
            </form>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var form = document.getElementById('pedidoForm');
        var continuarInsercao = false;  // Variável de controle para decidir se continua ou não

        form.addEventListener('submit', function(event) {
            event.preventDefault(); // Previne o envio tradicional do formulário

            // Verificar se a posição já está ocupada
            var localPosicao = document.getElementById('localPosicao').value;
            var formData = new FormData(form); // Captura os dados do formulário

            var xhr = new XMLHttpRequest();
            xhr.open("POST", "../config-DB/verificar-posicao.php", true);
            xhr.onload = function() {
                if (xhr.status >= 200 && xhr.status < 300) {
                    var response = JSON.parse(xhr.responseText);

                    if (response.ocupado && !continuarInsercao) {
                        // Se a posição está ocupada e ainda não foi permitido continuar
                        document.getElementById('mensagem').innerHTML = 
                            "A posição " + localPosicao + " já está ocupada pelo pedido número " + response.numero_pedido +
                            ". Deseja continuar assim mesmo? <br><div id='btn-conf'><button id='btnContinuar'>Continuar</button> <button id='btnCancelar'>Cancelar</button></div>";

                        // Ação para cancelar
                        document.getElementById('btnCancelar').addEventListener('click', function() {
                            document.getElementById('mensagem').innerHTML = ''; // Limpa a mensagem
                        });

                        // Ação para continuar
                        document.getElementById('btnContinuar').addEventListener('click', function() {
                            continuarInsercao = true;
                            inserirPedido(formData);  // Chama a função de inserção do pedido
                        });
                    } else {
                        // Se não está ocupado ou se o usuário clicou em "Continuar"
                        inserirPedido(formData);  // Função que insere o pedido no banco de dados
                    }
                } else {
                    document.getElementById('mensagem').innerHTML = "Erro ao verificar a posição.";
                }
            };
            xhr.onerror = function () {
                document.getElementById('mensagem').innerHTML = "Erro ao processar a solicitação.";
            };
            xhr.send(formData);
        });

        // Função para inserir o pedido no banco de dados
        function inserirPedido(formData) {
            var xhrInserir = new XMLHttpRequest();
            xhrInserir.open("POST", "../config-DB/inserir-pedido.php", true);
            xhrInserir.onload = function() {
                if (xhrInserir.status >= 200 && xhrInserir.status < 300) {
                    var response = JSON.parse(xhrInserir.responseText);

                    // Exibe a mensagem de sucesso ou erro
                    document.getElementById('mensagem').innerHTML = response.message;

                    if (response.success) {
                        // Limpa o formulário após a inserção bem-sucedida
                        form.reset();

                        // Limpa a mensagem após alguns segundos
                        setTimeout(function() {
                            document.getElementById('mensagem').innerHTML = '';
                        }, 4000);

                        // Resetar o controle de inserção
                        continuarInsercao = false;
                    }
                } else {
                    document.getElementById('mensagem').innerHTML = "Erro ao inserir o pedido.";
                }
            };
            xhrInserir.onerror = function() {
                document.getElementById('mensagem').innerHTML = "Erro ao processar a inserção.";
            };
            xhrInserir.send(formData);
        }

        // Inicializa a data no campo oculto
        var dataAtual = new Date();
        var dia = String(dataAtual.getDate()).padStart(2, '0');
        var mes = String(dataAtual.getMonth() + 1).padStart(2, '0'); // Janeiro é 0
        var ano = dataAtual.getFullYear();
        var dataFormatada = ano + '-' + mes + '-' + dia; // Formato YYYY-MM-DD
        document.getElementById('dataPedido').value = dataFormatada;
    });
</script>


</body>
</html>
