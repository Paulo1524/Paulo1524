<?php 
include 'navbar.php'; 
include '../auth/db-login.php';

if ($_SESSION['permissao_liberar_acesso'] != 1) {
    header("Location: dashboard.php");
    exit;
}

// Verificar e alterar a permissão, se necessário
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['id']) && isset($_POST['newAccess'])) {
        // Alterar nível de acesso
        $stmt = $conn->prepare("UPDATE usuarios SET acesso = ? WHERE id = ?");
        $stmt->bind_param('ii', $_POST['newAccess'], $_POST['id']);
        $stmt->execute();
        header("Location: liberar-acesso.php"); // Recarrega a página para mostrar a atualização
    } elseif (isset($_POST['id']) && isset($_POST['delete'])) {
        // Excluir o usuário
        $stmt = $conn->prepare("DELETE FROM usuarios WHERE id = ?");
        $stmt->bind_param('i', $_POST['id']);
        $stmt->execute();
        header("Location: dashboard.php"); // Recarrega a página para mostrar a exclusão
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../src/style/liberar-acesso.css">
    <title>Privilégios</title>
</head>
<body>
    <div id="box">
        <h1 id="title">Privilégios</h1>
        <p>Usuários com nível de acesso 0 têm acesso restrito e não podem utilizar as funcionalidades do sistema. <br>
        Usuários com nível de acesso 1 têm permissão completa para gerenciar e manipular os dados dentro do sistema.</p>
        <table>
            <thead>
                <tr>
                    <th>Email</th>
                    <th>Nível de Acesso</th>
                    <th>Ação</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $stmt = $conn->query("SELECT id, email, acesso FROM usuarios");
                while ($row = $stmt->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['acesso']) . "</td>";
                    echo "<td>";
                    // Formulário para alterar o nível de acesso
                    echo "<form method='post' style='display:inline;'>";
                    echo "<input type='hidden' name='id' value='" . $row['id'] . "'>";
                    echo "<input type='hidden' name='newAccess' value='" . ($row['acesso'] == 1 ? 0 : 1) . "'>";
                    echo "<input type='submit' value='Alterar Acesso'>";
                    echo "</form>";

                    // Formulário para excluir o usuário
                    echo "<form method='post' style='display:inline; margin-left: 10px;' onsubmit='return confirm(\"Tem certeza que deseja excluir este usuário?\");'>";
                    echo "<input type='hidden' name='id' value='" . $row['id'] . "'>";
                    echo "<input type='hidden' name='delete' value='1'>";
                    echo "<input type='submit' value='Excluir'>";
                    echo "</form>";

                    echo "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
