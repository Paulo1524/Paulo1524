<?php
include '../auth/session_manager.php';
include '../auth/db-login.php';  // Inclui configurações do banco de dados, se necessário
?>

<!-- Início do conteúdo da navbar -->
<nav>
    <!-- Logo à esquerda -->
    <a href="#" class="navbar-logo">
        <img src="../src/img/logo.png" alt="Logo">
    </a>

    <!-- Título do Sistema -->
    <h1 id="titulo">Sistema de Endereçamento de Pedidos</h1>

    <!-- Ícone do menu hamburguer -->
    <div class="navbar-toggle" id="mobile-menu">
        <span class="bar"></span>
        <span class="bar"></span>
    </div>

    <!-- Menu de navegação -->
    <ul class="navbar-menu">
        <?php if ($_SESSION['acesso'] == 1): ?>
        <li><a href="dashboard.php">Início</a></li>
        <li><a href="novo-pedido.php">Novo Pedido</a></li>
        <li><a href="buscar-pedido.php">Buscar Pedido</a></li>
        <?php endif; ?>
        <!-- Checa a permissão para mostrar o link -->
        <?php if ($_SESSION['permissao_liberar_acesso'] == 1): ?>
        <li><a href="liberar-acesso.php">Liberar Acesso</a></li>
        <?php endif; ?>
        <li><a href="../auth/sair.php?logout=1">Sair</a></li>
    </ul>
</nav>

<!-- Script para o menu hamburguer -->
<script>
    const mobileMenu = document.getElementById('mobile-menu');
    const navbarMenu = document.querySelector('.navbar-menu');

    mobileMenu.addEventListener('click', () => {
        navbarMenu.classList.toggle('active'); // Adiciona ou remove a classe 'active' no menu
    });
</script>

<style>
    /* Estilos para a navbar fixa */
    nav {
        background-color: #212121;
        display: flex;
        align-items: center;
        justify-content: space-between;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        z-index: 1000;
        padding: 13px 20px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    /* Estilo para a logo */
    .navbar-logo img {
        height: 35px;
        width: auto;
    }

    /* Estilos para a lista de navegação */
    nav ul {
        list-style-type: none;
        margin: 0 50px;
        padding: 0;
        display: flex;
        align-items: center;
        flex-grow: 1;
        justify-content: center;
    }

    nav ul li {
        margin-right: 15px;
    }

    nav ul li a {
        border-radius: 6px;
        display: block;
        color: white;
        text-align: center;
        padding: 5px 18px;
        text-decoration: none;
        transition: background-color 0.3s ease;
        background-color: #0877C7;
        white-space: nowrap;
    }

    nav ul li a:hover {
        background-color: #F57E1A;
        border-radius: 6px;
    }

    /* Estilos para o menu hamburguer */
    .navbar-toggle {
        display: none;
        flex-direction: column;
        cursor: pointer;
    }

    .bar {
        height: 3px;
        width: 25px;
        background-color: white;
        margin: 3px 0;
    }

    #titulo {
        color: #0078C8;
        font-size: 22px;
        text-align: center;
        margin: 0 0px;
        flex-grow: 1;
        font-weight: bold;
    }

    @media (max-width: 1100px) {
        nav ul li a {
            padding: 6px 8px;
            font-size: 17px;
        }

        #titulo {
            display: none;
        }
    }

    /* Responsividade para telas menores */
    @media (max-width: 700px) {
        nav ul li a {
            background-color: #333;
        }

        nav {
            flex-direction: row;
        }

        nav ul {
            display: none;
            flex-direction: column;
            width: 100%;
            background-color: #333;
            position: absolute;
            top: 60px;
            left: 0;
            z-index: 999;
            margin: 0;
        }

        nav ul.active {
            display: flex;
        }

        .navbar-toggle {
            display: flex;
            margin-right: 50px;
        }

        .navbar-logo img {
            height: 30px;
            width: auto;
        }

        .navbar-menu {
            margin-top: -10px;
        }

        #titulo {
            display: none;
        }
    }
</style>
<!-- Fim do conteúdo da navbar -->
