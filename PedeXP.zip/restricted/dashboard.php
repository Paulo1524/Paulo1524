<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'navbar.php';
include '../config-DB/DB-pedidos.php';  // Inclui a conexão com o banco de dados

$pedidos = [];

// Verifica se o usuário tem acesso
if (isset($_SESSION['acesso']) && $_SESSION['acesso'] == 1) {
    // Ajusta a consulta SQL para a nova estrutura
    $sql = "SELECT numero_pedido, data_pedido, quantidade_pedido, local_pedido 
            FROM Pedidos 
            ORDER BY id_pedido DESC
            LIMIT 12";  // Limita a busca aos 12 primeiros registros

    // Executa a consulta e verifica se teve sucesso
    $result = $conn->query($sql);

    if ($result) {
        $pedidos = $result->fetch_all(MYSQLI_ASSOC);
    } else {
        echo "Erro na consulta SQL: " . $conn->error;
    }
} else {
    echo "Acesso negado.";
}

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../src/style/dashboard.css">
    <title>Início</title>
</head>
<body>
    <div id="box">
        <h1 id="title">Pedidos Endereçados</h1>
        <?php if (isset($_SESSION['user_id']) && $_SESSION['acesso'] == 1): ?>
            <?php if (count($pedidos) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Número do Pedido</th>
                            <th>Data do Pedido</th>
                            <th>Quantidade de Volumes</th>
                            <th>Local/Posição do Pedido</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pedidos as $pedido): ?>
                        <tr>
                            <td><?= htmlspecialchars($pedido['numero_pedido']) ?></td>
                            <td><?= htmlspecialchars($pedido['data_pedido']) ?></td>
                            <td><?= htmlspecialchars($pedido['quantidade_pedido']) ?></td>
                            <td><?= htmlspecialchars($pedido['local_pedido']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>Nenhum pedido encontrado.</p>
            <?php endif; ?>
        <?php else: ?>
            <h1 id="title" style="color: red;">Acesso negado. Você não tem permissão para acessar esta página.</h1>
        <?php endif; ?>
    </div>
</body>
</html>
